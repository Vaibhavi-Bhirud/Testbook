I have created all the projects which mentioned in
hackthon 1.0 assignments.
I used Vs code for this tasks.
I am attaching a video file for output.
 