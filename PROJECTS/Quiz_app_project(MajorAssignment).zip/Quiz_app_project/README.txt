This is Simple Quiz App using HTML, CSS, JAVASCRIPT.
I attached screen recording for quiz view.