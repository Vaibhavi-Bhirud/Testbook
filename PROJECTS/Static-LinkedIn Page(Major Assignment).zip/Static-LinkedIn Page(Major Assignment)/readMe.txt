Static LinkedIn Page Major Assignment:
I am attaching a preveiw of webpage in picture format.
This is static linkedin page.